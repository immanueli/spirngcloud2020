package com.liuscoding.springcloud.alibaba.service;

import com.liuscoding.springcloud.alibaba.entity.Order;

/**
 * @className: OrderService
 * @description:
 * @author: liusCoding
 * @create: 2020-06-12 09:27
 */

public interface OrderService {
    void create(Order order);
}
