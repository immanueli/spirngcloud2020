package com.liuscoding.springcloud.service;

public interface IMessageProvider {
    String send();
}
